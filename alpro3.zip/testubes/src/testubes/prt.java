/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testubes;

/**
 *
 * @author MY-COMPUTER
 */
public class prt implements pekerja{
    int gajiPerHari;
    int durasiKerja;
    public int totalGaji;
    @Override
    public int totalGaji(){
        int durasiKerja = Integer.parseInt(Halaman.TabelPRT.masakerja.getText());
        int gajiPerHari = Integer.parseInt(Halaman.TabelPRT.gaji.getText());
        totalGaji = durasiKerja * gajiPerHari; 
        return totalGaji;
    }
}